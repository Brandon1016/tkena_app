<script setup>
import {computed, inject, ref, onMounted, onBeforeUnmount} from "vue"
import { formFieldKey } from "@/shared/services/formField"
import PureIcon from "./PureIcon.vue"


const wrapper = ref(null)

const select = (option) => {
  const value = option[props.valueKey]

  emit("update:modelValue", value)
  emit("change", value)

  open.value = false
}

const handleClickOutside = (event) => {
  if (!wrapper.value?.contains(event.target)) {
    open.value = false
  }
}

onMounted(() => {
  document.addEventListener("click", handleClickOutside)
})

onBeforeUnmount(() => {
  document.removeEventListener("click", handleClickOutside)
})

const field = inject(formFieldKey, null)

const props = defineProps({
  id: {
    type: String,
    default: null
  },

  modelValue: {
    type: [String, Number],
    default: ""
  },

  options: {
    type: Array,
    default: () => []
  },

  placeholder: {
    type: String,
    default: ""
  },

  labelKey: {
    type: String,
    default: "label"
  },

  valueKey: {
    type: String,
    default: "value"
  },

  icon: {
    type: String,
    default: ""
  },

  required: {
    type: Boolean,
    default: undefined
  },

  invalid: {
    type: Boolean,
    default: undefined
  },

  disabled: {
    type: Boolean,
    default: false
  },

  readonly: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits([
  "update:modelValue",
  "change"
])

const open = ref(false)

const selected = computed(() =>
  props.options.find(
    option => option[props.valueKey] === props.modelValue
  )
)
</script>

<template>
<div ref="wrapper" class="select-wrapper" :class="{ 'is-open': open }">
    <button
        class="select-button"
        type="button"
        @click.stop="open = !open"
        :class = "{
          'is-error': invalid ?? field?.invalid?.value
        }"
    >
        <slot
            name="selected"
            :option="selected"
        >
            {{ selected?.[labelKey] || placeholder }}
        </slot>
        <PureIcon
            name="keyboard_arrow_down"
            class="select-arrow"
        />
    </button>
    <div
        v-if="open"
        class="dropdown"
    >
        <div
            v-for="option in options"
            :key="option[valueKey]"
            class="option"
            @click="select(option)"
        >
            <slot
                name="option"
                :option="option"
            >
                {{ option[labelKey] }}
            </slot>
        </div>
    </div>
</div>

</template>

<style scoped>
/* --- Select One --- */

.select-wrapper {
    position: relative;
    width: 100%;
}

.select-button {
    width: 100%;
    height: var(--input-heigth);

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 var(--space-10) 0 var(--space-4);

    background: var(--bg-surface);
  color: var(--text-secondary);

    font: inherit;

    border: 1px solid var(--border-color);
    border-radius: var(--radius-2xl);

    cursor: pointer;
    outline: none;

    transition:
        border-color .2s,
        box-shadow .2s,
        border-radius .15s;
}

.select-button:hover {
    border-color: var(--border-color-hover);
}

.select-button:focus {
    border-color: var(--focus-ring);
      border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;

}

.select-button:disabled {
    background: var(--bg-surface-elevated);
    color: var(--text-muted);
    cursor: not-allowed;
    opacity: .6;
}

.select-button.is-error {
    border-color: var(--state-danger);
}

.dropdown {
  padding-top: 20px;
  padding-bottom: 20px;
  position: absolute;


    top: calc(100% + 4px);
    left: 0;
    right: 0;

    z-index: var(--z-dropdown);

    max-height: min(320px, 40vh);
    overflow-y: auto;

    background: var(--bg-surface);

    border: 1px solid var(--border-color-hover);
    border-bottom-left-radius: var(--radius-2xl);
    border-bottom-right-radius: var(--radius-2xl);
    box-shadow: var(--shadow-lg);
transition:
        border-color .2s,
        box-shadow .2s,
        border-radius .15s;}

.option {
  padding-left: 10px;
    display: flex;
    align-items: center;
  line-height: 28px;
    cursor: pointer;
    transition: background .15s;
}

.option:hover {
    background: var(--color-tertiary-light);
}

.option.selected {
    background: var(--bg-surface-elevated);
}

.select-wrapper.is-open .select-button {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
}

.select-wrapper.is-open .dropdown {
    margin-top: -4px;

    border-top-left-radius: 0;
    border-top-right-radius: 0;
}
</style>