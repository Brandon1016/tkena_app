<script setup>
import { ref, computed, provide, onMounted, onUnmounted, nextTick, watch } from "vue"
import { dropdownKey } from "@/shared/services/dropdown"

const props = defineProps({
  placement: {
    type: String,
    default: "bottom-end"
  },

  closeOnClick: {
    type: Boolean,
    default: true
  },

  disabled: {
    type: Boolean,
    default: false
  },
 matchTriggerWidth: {
    type: Boolean,
    default: false
  }
})

const triggerWidth = ref(0)
const emit = defineEmits([
  "open",
  "close"
])

// -----------------------------------------------------------------------------
// State
// -----------------------------------------------------------------------------

const open = ref(false)

const triggerRef = ref(null)
const menuRef = ref(null)

const menuStyle = ref({})

// -----------------------------------------------------------------------------
// Methods
// -----------------------------------------------------------------------------

const openMenu = async () => {
  if (props.disabled) return

  open.value = true

  await nextTick()

  await new Promise(resolve => requestAnimationFrame(resolve))

  updatePosition()

  emit("open")
}

const closeMenu = () => {
  if (!open.value) return

  open.value = false

  emit("close")
}

const toggleMenu = () => {
  open.value ? closeMenu() : openMenu()
}
const updatePosition = () => {
  if (!triggerRef.value || !menuRef.value) return

  const trigger = triggerRef.value.getBoundingClientRect()

  if (props.matchTriggerWidth) {
    triggerWidth.value = trigger.width
  }

  const menu = menuRef.value.getBoundingClientRect()

  const gap = 0

  let top
  let left

  switch (props.placement) {
    case "bottom-start":
      top = trigger.bottom + gap
      left = trigger.left
      break

    case "bottom-end":
      top = trigger.bottom + gap
      left = trigger.right - menu.width
      break

    case "top-start":
      top = trigger.top - menu.height - gap
      left = trigger.left
      break

    case "top-end":
      top = trigger.top - menu.height - gap
      left = trigger.right - menu.width
      break
  }

  left = Math.max(
    gap,
    Math.min(left, window.innerWidth - menu.width - gap)
  )

    menuStyle.value = {
    position: "fixed",
    top: `${top}px`,
    left: `${left}px`,
    zIndex: 1000,
    ...(props.matchTriggerWidth && {
      width: `${triggerWidth.value}px`
    })
  }
}

const handleClickOutside = (event) => {
  if (
    triggerRef.value?.contains(event.target) ||
    menuRef.value?.contains(event.target)
  ) {
    return
  }

  closeMenu()
}

const handleEscape = (event) => {
  if (event.key === "Escape") {
    closeMenu()
  }
}

const handleWindowChange = () => {
  if (open.value) {
    updatePosition()
  }
}
watch(menuRef, (menu) => {
  if (menu) {
    updatePosition()
  }
})

// -----------------------------------------------------------------------------
// Provide
// -----------------------------------------------------------------------------

provide(dropdownKey, {
  close: closeMenu,
  closeOnClick: computed(() => props.closeOnClick)
})

// -----------------------------------------------------------------------------
// Lifecycle
// -----------------------------------------------------------------------------

onMounted(() => {
  document.addEventListener("click", handleClickOutside)
  document.addEventListener("keydown", handleEscape)

  window.addEventListener("resize", handleWindowChange)
  window.addEventListener("scroll", handleWindowChange, true)
})

onUnmounted(() => {
  document.removeEventListener("click", handleClickOutside)
  document.removeEventListener("keydown", handleEscape)

  window.removeEventListener("resize", handleWindowChange)
  window.removeEventListener("scroll", handleWindowChange, true)
})
</script>

<template>
  <div class="dropdown">

    <div
      ref="triggerRef"
      class="dropdown-trigger"
      @click="toggleMenu"
    >
      <slot name="trigger" />
    </div>

    <Teleport to="body">

      <Transition name="dropdown">

        <div
          v-if="open"
          ref="menuRef"
          class="dropdown-menu"
          :style="menuStyle"
        >
          <slot />
        </div>

      </Transition>

    </Teleport>

  </div>
</template>